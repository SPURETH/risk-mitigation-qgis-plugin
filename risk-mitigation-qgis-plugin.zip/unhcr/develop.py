import platform

# Determine the operating system
operating_system = platform.system()

print(operating_system)
